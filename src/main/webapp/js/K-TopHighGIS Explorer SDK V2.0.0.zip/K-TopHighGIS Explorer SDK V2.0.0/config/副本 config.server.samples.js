﻿var samplesTree=[
  {
      "text": "地图控件",
      "child": [
      {
          "text": "地图初始化",
          "sendpagename": "../apisample/control/initmap.html"
      },
      {
          "text": "导航控件",
          "sendpagename": "../samples/control.navigate.html"
      },
      {
          "text": "比例尺",
          "sendpagename": "../../samples/control.scalemap.html"
      },
      {
          "text": "鹰眼",
          "sendpagename": "../../samples/control.minimap.html"
      },
      {
          "text": "地图工具栏",
          "sendpagename": "../../samples/control.navbar.html"
      },
	  {
	      "text": "多屏展示",
	      "sendpagename": "../../samples/control.multiScreen.html"
	  },
      {
          "text": "指北针",
          "sendpagename": "../../samples/control.compass.html"
      },
      {
          "text": "鼠标位置提示",
          "sendpagename": "../../samples/control.mouseposition.html"
      },
      {
          "text": "鼠标Tooltip",
          "sendpagename": "../../samples/control.tooltip.html"
      },
      {
          "text": "添加自定义控件",
          "sendpagename": "../../samples/control.custom.html"
      }
    ]
  },
  {
      "text": "地图控制",
      "child": [
      {
          "text": "放大、缩小、平移",
          "sendpagename": "../../samples/setcontrol.state.html"
      },

      {
          "text": "地图定位",
          "sendpagename": "../../samples/setcontrol.mapposition.html"
      },
      {
          "text": "获取级数",
          "sendpagename": "../../samples/setcontrol.zoom.html"
      },
      {
          "text": "获取分辨率",
          "sendpagename": "../../samples/setcontrol.resolution.html"
      },
      {
          "text": "获取地图范围",
          "sendpagename": "../../samples/setcontrol.mapview.html"
      },
      {
          "text": "图层控制",
          "sendpagename": "../../samples/setcontrol.layers.html"
      }
    ]
  },
  {
      "text": "图形操作",
      "child": [
      {
          "text": "添加点",
          "sendpagename": "../../samples/graphic.addmark.html"
      },
      {
          "text": "添加线",
          "sendpagename": "../../samples/graphic.addline.html"
      },
      {
          "text": "添加圆",
          "sendpagename": "../../samples/graphic.addcircle.html"
      },
      {
          "text": "添加矩形",
          "sendpagename": "../../samples/graphic.addrectangle.html"
      },
      {
          "text": "添加多边形",
          "sendpagename": "../../samples/graphic.addpolygon.html"
      },
      {
          "text": "图形绘制",
          "sendpagename": "../../samples/graphic.draw.html"
      },
      {
          "text": "图形编辑",
          "sendpagename": "../../samples/graphic.edit.html"
      }
    ]
  },
  {
      "text": "地图标注",
      "child": [
      {
          "text": "圆形标注",
          "sendpagename": "../../samples/annotate.lablecircle.html"
      },
      {
          "text": "图形标注",
          "sendpagename": "../../samples/annotate.images.html"
      },
      {
          "text": "自定义标注",
          "sendpagename": "../../samples/annotate.definelable.html"
      },
      {
          "text": "POPUP弹出框",
          "sendpagename": "../../samples/annotate.popup.html"
      }
    ]
  },
  {
      "text": "图层加载",
      "child": [
      {
          "text": "WMS-imageoverlay方式",
          "sendpagename": "../apisample/showmap/wms.imageoverlay.html"
      },
      {
          "text": "WMTS",
          "sendpagename": "../../samples/layers.wmts.html"
      },
      {
          "text": "Arcgis矢量服务",
          "sendpagename": "../../samples/layers.arcgis.dynamic.html"
      },
      {
          "text": "Arcgis瓦片服务",
          "sendpagename": "../../samples/layers.arcgis.tile.html"
      },
      {
          "text": "天地图",
          "sendpagename": "../../samples/layers.tdt.html"
      },
      {
          "text": "Geojson",
          "sendpagename": "../../samples/layers.geojson.html"
      },
      {
          "text": "KML",
          "sendpagename": "../../samples/layers.kml.html"
      },
      {
          "text": "WKB",
          "sendpagename": "../../samples/layers.wkb.html"
      },
      {
          "text": "WKT",
          "sendpagename": "../../samples/layers.wkt.html"
      }
    ]
  },
  {
      "text": "测量",
      "child": [
      {
          "text": "测量长度、面积",
          "sendpagename": "../../samples/measure.length.area.html"
      }
    ]
  },
  {
      "text": "专题图",
      "child": [
      {
          "text": "热力图",
          "sendpagename": "../../samples/subject.heatmap.html"
      },
      {
          "text": "颜色分段渲染图",
          "sendpagename": "../../samples/subject.rendermap.html"
      },
      {
          "text": "散点图",
          "sendpagename": "../../samples/subject.single.scatter.html"
      },
      {
          "text": "动画散点图",
          "sendpagename": "../../samples/subject.effect.scatter.html"
      },

      {
          "text": "轨迹动态专题图",
          "sendpagename": "../../samples/subject.dynamic.path.html"
      },
      {
          "text": "Echarts专题图",
          "sendpagename": "../../samples/subject.echarts.html"
      },
      {
          "text": "专题图叠加",
          "sendpagename": "../../samples/subject.scatter.html"
      },
      {
          "text": "标记聚类默认",
          "sendpagename": "../../samples/subject.markercluster.default.html"
      },
      {
          "text": "标记聚类自定义",
          "sendpagename": "../../samples/subject.markercluster.custom.html"
      },
      {
          "text": "标记聚类大数据加载",
          "sendpagename": "../../samples/subject.markercluster.bigdata.html"
      }
    ]
  },
  {
      "text": "查询服务",
      "child": [
      {
          "text": "WFS组合查询",
          "sendpagename": "../../samples/inqservice.wfs.query.html"
      }
    ]
  }
,
  {
      "text": "WPS分析",
      "child": [
      {
          "text": "WPS分析",
          "sendpagename": "../../samples/inqservice.wps.query.html"
      }
    ]
  },
  {
      "text": "MapGIS服务",
      "child": [
      {
          "text": "加载MapGIS地图文档",
          "sendpagename": "../../samples/zondy.Doc.html"
      },
	  {
	      "text": "加载MapGIS瓦片地图",
	      "sendpagename": "../../samples/zondy.TileLayer.html"
	  },
	  {
	      "text": "加载MapGIS矢量图层",
	      "sendpagename": "../../samples/zondy.VectorLayer.html"
	  },
	  {
	      "text": "属性查询",
	      "sendpagename": "../../samples/zondy.query.attribute.htm"
	  },
	  {
	      "text": "点查询",
	      "sendpagename": "../../samples/zondy.query.pnt.htm"
	  },
	  {
	      "text": "线查询",
	      "sendpagename": "../../samples/zondy.query.line.htm"
	  },
	  {
	      "text": "矩形查询",
	      "sendpagename": "../../samples/zondy.query.rect.htm"
	  },
	  {
	      "text": "圆查询",
	      "sendpagename": "../../samples/zondy.query.circle.htm"
	  },
	  {
	      "text": "多边形查询",
	      "sendpagename": "../../samples/zondy.query.polygon.htm"
	  },
	  {
	      "text": "多区查询",
	      "sendpagename": "../../samples/zondy.query.multipPolygon.htm"
	  },
	  {
	      "text": "Fid查询",
	      "sendpagename": "../../samples/zondy.query.fid.htm"
	  },
	  {
	      "text": "点查询（图层）",
	      "sendpagename": "../../samples/zondy.query.pnt(layer).htm"
	  }
    ]
  },
  {
      "text": "应用案例",
      "child": [
      {
          "text": "流域分析",
          "sendpagename": "../../samples/sample.Analyse.Demo.html"
      }
    ]
  }
]