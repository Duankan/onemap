﻿var samplesTree=[
  {
      "text": "图层加载",
      "child": [
      {
          "text": "wms",
          "sendpagename": "../apisample/showmap/wms.nonTiledLayer.html"
      },
      {
           "text": "wms过滤(cql_filter)",
           "sendpagename": "../apisample/showmap/wms.nonTiledLayer.cqlfilter.html"
       },
       {
           "text": "wms过滤(filter)",
           "sendpagename": "../apisample/showmap/wms.nonTiledLayer.filter.html"
       },
      {
          "text": "wms-post",
          "sendpagename": "../apisample/showmap/wms.nonTiledLayer.post.html"
      },
      {
          "text": "wmts-ktw(通用方式)",
          "sendpagename": "../apisample/showmap/wmts.ktw(currency).html"
      },
      {
          "text": "wmts-arcgis(通用方式)",
          "sendpagename": "../apisample/showmap/wmts.arcgis.html"
      },
      {
          "text": "wmts-mapgis(通用方式)",
          "sendpagename": "../apisample/showmap/wmts.mapgis.html"
      },
      {
          "text": "wmts-ktw(标准出图)",
          "sendpagename": "../apisample/showmap/wmts.ktw(TDT_Standard).html"
      },
      {
          "text": "百度地图",
          "sendpagename": "../apisample/showmap/othermaps.baidu.html"
      },
      {
          "text": "Geojson",
          "sendpagename": "../apisample/showmap/layers.geojson.html"
      },
      {
          "text": "wkt",
          "sendpagename": "../apisample/showmap/layers.wkt.html"
      }
    ]
  },
  {
      "text": " 地图控制",
      "child": [
          {
              "text": "放大、缩小、平移",
              "sendpagename": "../apisample/mapoperation/map.operation.html"
          },

          {
              "text": "地图定位",
              "sendpagename": "../apisample/mapoperation/map.position.html"
          },
          {
              "text": "级数定位",
              "sendpagename": "../apisample/mapoperation/map.zoom.html"
          },
          {
              "text": "获取地图容器信息",
              "sendpagename": "../apisample/mapoperation/map.mapview.html"
          },
          {
              "text": "设置地图背景",
              "sendpagename": "../apisample/mapoperation/map.setbackground.html"
          }
    ]
  },
  {
      "text": "地图控件",
      "child": [
      {
          "text": "导航控件",
          "sendpagename": "../apisample/control/control.navigate.html"
      },
      {
          "text": "比例尺",
          "sendpagename": "../apisample/control/control.scalemap.html"
      },
      {
          "text": "鹰眼",
          "sendpagename": "../apisample/control/control.minimap.html"
      },
	  {
	      "text": "多屏展示",
	      "sendpagename": "../apisample/control/control.multiScreen.html"
	  },
      {
          "text": "卷帘",
          "sendpagename": "../apisample/control/control.sideBySide.html"
      },
     
      {
          "text": "鼠标位置提示",
          "sendpagename": "../apisample/control/control.mouseposition.html"
      },
      {
          "text": "图层控件",
          "sendpagename": "../apisample/control/control.layercontrol.html"
      },
      {
          "text": "添加自定义控件",
          "sendpagename": "../apisample/control/control.custom.html"
      }
    ]
  },
  {
      "text": "图形操作",
      "child": [
      {
          "text": "添加点",
          "sendpagename": "../apisample/graphicoperation/graphic.addmark.html"
      },
      {
          "text": "添加线",
          "sendpagename": "../apisample/graphicoperation/graphic.addline.html"
      },
      {
          "text": "添加圆",
          "sendpagename": "../apisample/graphicoperation/graphic.addcircle.html"
      },
      {
          "text": "添加矩形",
          "sendpagename": "../apisample/graphicoperation/graphic.addrectangle.html"
      },
      {
          "text": "添加多边形",
          "sendpagename": "../apisample/graphicoperation/graphic.addpolygon.html"
      },
      {
          "text": "图形绘制(默认控件)",
          "sendpagename": "../apisample/graphicoperation/graphic.draw(control).html"
      },
      {
          "text": "图形绘制(自定义)",
          "sendpagename": "../apisample/graphicoperation/graphic.draw.html"
      },
      {
          "text": "图形编辑",
          "sendpagename": "../apisample/graphicoperation/graphic.edit.html"
      },
      {
          "text": "获取绘制信息",
          "sendpagename": "../apisample/graphicoperation/graphic.getdrawlnglats.html"
      }
    ]
  },
  {
      "text": "查询服务(KTW-WFS)",
      "child": [
      {
          "text": "点查询",
          "sendpagename": "../apisample/wfs-ktw/query.pnt.html"
      },
      {
          "text": "线查询",
          "sendpagename": "../apisample/wfs-ktw/query.line.html"
      },
      {
          "text": "矩形查询",
          "sendpagename": "../apisample/wfs-ktw/query.rect.html"
      },
      {
          "text": "多边形查询",
          "sendpagename": "../apisample/wfs-ktw/query.polygon.html"
      },
      {
          "text": "属性查询",
          "sendpagename": "../apisample/wfs-ktw/query.property.html"
      },
      {
          "text": "属性+几何查询",
          "sendpagename": "../apisample/wfs-ktw/query.property.geo.html"
      },
      {
          "text": "FID查询",
          "sendpagename": "../apisample/wfs-ktw/query.fid.html"
      },
      {
          "text": "缓冲查询",
          "sendpagename": "../apisample/wfs-ktw/query.radius.html"
      },
      {
          "text": "查询返回临时图层",
          "sendpagename": "../apisample/wfs-ktw/query.returnwms.html"
      }
    ]
  },
  {
      "text": "查询服务(WFS-通用标准)",
      "child": [
      {
          "text": "标准查询-几何查询",
          "sendpagename": "../apisample/wfs/wfs.query.polygon.html"
      },
       {
           "text": "标准查询-属性查询",
           "sendpagename": "../apisample/wfs/wfs.query.attribute.html"
       }
    ]
  },
  {
      "text": "WPS分析",
      "child": [
          {
              "text": "量算",
              "sendpagename": "../apisample/wps1.0/wps.measure.html"
          },
          {
              "text": "投影",
              "sendpagename": "../apisample/wps1.0/wps.project.html"
          },
          {
              "text": "缓冲",
              "sendpagename": "../apisample/wps1.0/wps.buffer.html"
          },
          {
              "text": "图形叠加",
              "sendpagename": "../apisample/wps1.0/wps.overlay.html"
          }
    ]
  },
  {
      "text": "专题图",
      "child": [
      {
          "text": "热力图",
          "sendpagename": "../apisample/theme/theme.heatMap.html"
      },
      {
          "text": "分段专题图",
          "sendpagename": "../apisample/theme/theme.colorRenderLayer.html"
      },
      {
          "text": "分段专题图(可设置分段)",
          "sendpagename": "../apisample/theme/theme.rangTheme.html"
      },
      {
          "text": "散点图(canvas方式)",
          "sendpagename": "../apisample/theme/theme.scatter.canvas.html"
      },
      {
          "text": "散点图(svg方式)",
          "sendpagename": "../apisample/theme/theme.scatter.svg.html"
      },
      {
          "text": "分段专题图叠加svg散点图",
          "sendpagename": "../apisample/theme/theme.scatter.range.html"
      },
      {
          "text": "动画散点图",
          "sendpagename": "../apisample/theme/theme.pointAnimate.html"
      },

      {
          "text": "轨迹动态专题图",
          "sendpagename": "../apisample/theme/theme.dynamicpathlayer.htm"
      },
      {
          "text": "Echarts专题图",
          "sendpagename": "../apisample/theme/subject.echarts.html"
      },
      {
          "text": "标记聚类默认",
          "sendpagename": "../apisample/theme/theme.markerClusterGroup.html"
      },
      {
          "text": "标记聚类自定义",
          "sendpagename": "../apisample/theme/theme.markerClusterGroupCustom.html"
      }
    ]
  },
  {
      "text": "客户端专题图",
      "child": [
          {
              "text": "客户端专题图-图层",
              "sendpagename": "../apisample/clientTheme/02_clienttheme_polygon.htm"
          },
          {
              "text": "客户端专题图-自定义数据",
              "sendpagename": "../apisample/clientTheme/03_clienttheme_data.htm"
          },
          {
              "text": "客户端专题图-单柱状图",
              "sendpagename": "../apisample/clientTheme/04_clienttheme_data_single.htm"
          }
    ]
  },
  {
      "text": "MapGIS",
      "child": [
      {
          "text": "加载MapGIS地图文档",
          "sendpagename": "../apisample/zondy/zondyDoc.html"
      },
	  {
	      "text": "加载MapGIS瓦片地图",
	      "sendpagename": "../apisample/zondy/zondyTileLayer.html"
	  },
	  {
	      "text": "加载MapGIS矢量图层",
	      "sendpagename": "../apisample/zondy/zondyVectorLayer.html"
	  },
	  {
	      "text": "属性查询",
	      "sendpagename": "../apisample/zondy/zondy.query.attribute.htm"
	  },
	  {
	      "text": "点查询",
	      "sendpagename": "../apisample/zondy/zondy.query.pnt.htm"
	  },
	  {
	      "text": "线查询",
	      "sendpagename": "../apisample/zondy/zondy.query.line.htm"
	  },
	  {
	      "text": "矩形查询",
	      "sendpagename": "../apisample/zondy/zondy.query.rect.htm"
	  },
	  {
	      "text": "圆查询",
	      "sendpagename": "../apisample/zondy/zondy.query.circle.htm"
	  },
	  {
	      "text": "多边形查询",
	      "sendpagename": "../apisample/zondy/zondy.query.polygon.htm"
	  },
	  {
	      "text": "多区查询",
	      "sendpagename": "../apisample/zondy/zondy.query.multipPolygon.htm"
	  },
	  {
	      "text": "Fid查询",
	      "sendpagename": "../apisample/zondy/zondy.query.fid.htm"
	  },
	  {
	      "text": "点查询（图层）",
	      "sendpagename": "../apisample/zondy/zondy.query.pnt(layer).htm"
	  },
      {
          "text": "多边形查询（图层）",
          "sendpagename": "../apisample/zondy/zondy.query.polygon(Layer).htm"
      }
    ]
  },
   {
       "text": "ArcGIS",
       "child": [
          {
              "text": "加载基础地图",
              "sendpagename": "../apisample/arcgis/basemapLayer.html"
          },
          {
              "text": "加载矢量",
              "sendpagename": "../apisample/arcgis/dynamicMapLayer.html"
          },
          {
              "text": "加载瓦片",
              "sendpagename": "../apisample/arcgis/tiledMapLayer.html"
          },
          {
              "text": "identify查询(几何)",
              "sendpagename": "../apisample/arcgis/identify.html"
          },
          {
              "text": "query查询(属性)",
              "sendpagename": "../apisample/arcgis/query.html"
          }
        ]
      },
   {
       "text": "SuperMap",
       "child": [
          {
              "text": "加载矢量",
              "sendpagename": "../apisample/supermap/imageMapLayer.html"
          },
          {
              "text": "加载瓦片",
              "sendpagename": "../apisample/supermap/tileMapLayer.html"
          },
          {
              "text": "属性查询",
              "sendpagename": "../apisample/supermap/query_sql.html"
          },
          {
              "text": "几何查询",
              "sendpagename": "../apisample/supermap/query_geom.html"
          }
    ]
   }
]