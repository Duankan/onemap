/**
 * Copyright © 2017 KingTopWare Corporation. All rights reserved.
 *
 * @title: config
 * @prject:
 * @description: 地图服务配置文件
 * @author: huangge
 * @date: 2018/7/18
 * @version: v1.0
 * @modify: 说明对该文件的修改内容、修改原因以及修改日期--请后续修改
 */
var config_url = "http://192.168.1.107:8081/master";
var config = {
    cfg_mapview: {
        crs: 'L.CRS.EPSG4326',
        center: '{ lon: 112, lat: 27 }',
        zoom: '6',
        minZoom: '0',
        maxZoom: '16'
    },
    cfg_wms: {
        url: '"' + config_url + '/wms"',
        options: { layers: 'ktw:city432601', format: 'image/png', version: '1.1.1' }
    },

    cfg_wmts: {
        url: '"' + config_url + '/wmts"',
        center: '{ lon: 112.25, lat: 28.707 }',
        zoom: '8',
        minZoom: '0',
        maxZoom: '10',
        crs: 'L.CRS.EPSG4326',
        layer: '"ktw:HNDom071701"'
    },
    cfg_wmts_arcigs: {
        url: '"http://services.arcgisonline.com/arcgis/rest/services/ESRI_Imagery_World_2D/MapServer/WMTS/1.0.0/WMTSCapabilities.xml"',
        layer: '"ESRI_Imagery_World_2D"'

    },
    cfg_wmts_mapgis: {
        url: '"http://127.0.0.1:6163/igs/rest/ogc/worldjw_wmts/WMTSServer/1.0.0/WMTSCapabilities.xml"',
        zoom: '6',
        layer: '"worldjw_wmts"',
        proxy: '"ZDproxy.ashx"'
    },
    cfg_wfs: {
        url: '"' + config_url + '/wfs"',
        layer: '"ktw:city432601"'
    },
    cfg_wps: {
        url: '"' + config_url + '/wps"',
    }


};

var commonConfig = config;